import type { ApiRequest, HttpMethod, RequestOptions, RawClientOptions } from "./api-request.js";
import { CoreError, ConnectionError, DecodeError, TimeoutError } from "./errors.js";
import { decodeErrorPayload, type AnyApiError, type ResponseHandler } from "./api-error.js";
import { decodeResponse } from "./response-decoder.js";
import { ApiPromise, type RequestOutcome } from "./api-promise.js";
import { buildBody } from "./request-body.js";
import { RetryPolicy } from "./retry.js";
import { UrlBuilder } from "./url.js";
import { HeadersBuilder } from "./headers.js";
import { authenticateRequest } from "./auth/schemes.js";

export class RawClient {
  readonly #config: RawClientOptions;
  readonly #urlBuilder: UrlBuilder;
  readonly #headersBuilder: HeadersBuilder;

  constructor(config: RawClientOptions) {
    this.#config = config;
    this.#urlBuilder = new UrlBuilder(config);
    this.#headersBuilder = new HeadersBuilder(config);
  }

  execute<T, E extends AnyApiError, Path extends string>(
    apiRequest: ApiRequest<Path>,
    responseHandler: ResponseHandler<T, E>,
    options?: RequestOptions,
  ): ApiPromise<T, E> {
    return new ApiPromise<T, E>(this.#dispatch<T, E>(apiRequest, responseHandler, options));
  }

  async #dispatch<T, E extends AnyApiError>(
    apiRequest: ApiRequest,
    responseHandler: ResponseHandler<T, E>,
    options: RequestOptions | undefined,
  ): Promise<RequestOutcome<T, E>> {
    const callerSignal = options?.signal ?? neverAbortedSignal();
    const uploadController = new AbortController();

    const url = this.#urlBuilder.build(apiRequest);
    const { uri } = url;

    const body = buildBody(
      apiRequest.method,
      uri,
      apiRequest.body,
      AbortSignal.any([callerSignal, uploadController.signal]),
    );

    const headers = this.#headersBuilder.build(apiRequest, uri, body);

    const policy = new RetryPolicy(options?.retry, this.#config.retry);

    const response = await policy.execute(apiRequest.method, callerSignal, async (timeout) => {
      const authenticated = await authenticateRequest(
        apiRequest.method,
        apiRequest.auth,
        url,
        headers,
        callerSignal,
      );

      const isStreaming = body.streaming === true;
      const timeoutController = new AbortController();
      const signal = AbortSignal.any([callerSignal, timeoutController.signal]);
      if (isStreaming) {
        timeoutController.signal.addEventListener(
          "abort",
          () => uploadController.abort(timeoutController.signal.reason),
          { once: true },
        );
      }

      const timer = startTimeout(timeoutController, timeout, apiRequest.method, uri);
      let response: Response;
      try {
        response = await this.#config.fetch.call(undefined, authenticated.url, {
          method: apiRequest.method,
          headers: authenticated.headers,
          body: body.body,
          signal,
          ...(isStreaming ? { duplex: "half", window: null, redirect: "error" } : {}),
        });
      } catch (err) {
        if (err instanceof ConnectionError || err instanceof TimeoutError)
          return { kind: "fault", error: err, isStreaming };
        if (err instanceof CoreError) throw err;
        if (signal.aborted) throw signal.reason;
        return {
          kind: "fault",
          error: new ConnectionError(
            `${apiRequest.method} ${uri} failed: ${
              err instanceof Error && err.message !== "" ? err.message : "Connection error."
            }`,
            { cause: err, method: apiRequest.method, uri },
          ),
          isStreaming,
        };
      } finally {
        clearTimeout(timer);
      }

      if (response.status === 401) apiRequest.auth.invalidate?.();
      return {
        kind: "response",
        response,
        isStreaming,
        discard: (): void => {
          void Promise.resolve(response.body?.cancel()).catch(() => {});
        },
      };
    });

    try {
      if (isSuccess(response.status)) {
        const data = await decodeResponse(responseHandler.success, response, apiRequest.method, uri);
        return { ok: true, status: response.status, headers: response.headers, data };
      }

      const payload = await decodeErrorPayload(
        response,
        responseHandler.errorFactory.errors,
        response.status,
        apiRequest.method,
        uri,
      );
      const error = new responseHandler.errorFactory({
        status: response.status,
        headers: response.headers,
        method: apiRequest.method,
        uri,
        payload,
      });

      return { ok: false, status: response.status, headers: response.headers, error };
    } catch (err) {
      if (callerSignal.aborted && err instanceof DecodeError && err.cause === callerSignal.reason)
        throw callerSignal.reason;
      throw err;
    }
  }
}

function isSuccess(status: number): boolean {
  return status >= 200 && status <= 299;
}

function neverAbortedSignal(): AbortSignal {
  return new AbortController().signal;
}

function startTimeout(
  controller: AbortController,
  timeoutMs: number,
  method: HttpMethod,
  uri: string,
): ReturnType<typeof setTimeout> {
  return setTimeout(
    () =>
      controller.abort(
        new TimeoutError(`${method} ${uri} failed: Request timed out after ${timeoutMs}ms.`, {
          method,
          uri,
          timeout: timeoutMs,
        }),
      ),
    timeoutMs,
  );
}
