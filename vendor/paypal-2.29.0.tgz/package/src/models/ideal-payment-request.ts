import * as s from "../core/validation/index.js";
import type { Schema } from "../core/validation/schema.js";
import { experienceContextSchema, type ExperienceContext } from "./experience-context.js";

/** Information needed to pay using iDEAL. */
export type IDealPaymentRequest = {
  /** The full name representation like Mr J Smith. */
  name: string;
  /**
   * The [two-character ISO 3166-1 code](/api/rest/reference/country-codes/) that identifies the
   * country or region. Note: The country code for Great Britain is GB and not UK as used in the
   * top-level domain names for that country. Use the `C2` country code for China worldwide for
   * comparable uncontrolled price (CUP) method, bank card, and cross-border transactions.
   */
  countryCode: string;
  /**
   * The business identification code (BIC). In payments systems, a BIC is used to identify a
   * specific business, most commonly a bank.
   */
  bic?: string;
  /** Customizes the payer experience during the approval process for the payment. */
  experienceContext?: ExperienceContext;
};

export const iDealPaymentRequestSchema: Schema<IDealPaymentRequest> = s.object<IDealPaymentRequest>({
  name: s.string(),
  countryCode: s.string(),
  bic: s.optional(s.string()),
  experienceContext: s.optional(s.lazy(() => experienceContextSchema)),
  _keysMap: {
    countryCode: "country_code",
    experienceContext: "experience_context",
  },
});
