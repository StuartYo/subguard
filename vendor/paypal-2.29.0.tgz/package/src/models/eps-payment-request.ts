import * as s from "../core/validation/index.js";
import type { Schema } from "../core/validation/schema.js";
import { experienceContextSchema, type ExperienceContext } from "./experience-context.js";

/** Information needed to pay using eps. */
export type EpsPaymentRequest = {
  /** The full name representation like Mr J Smith. */
  name: string;
  /**
   * The [two-character ISO 3166-1 code](/api/rest/reference/country-codes/) that identifies the
   * country or region. Note: The country code for Great Britain is GB and not UK as used in the
   * top-level domain names for that country. Use the `C2` country code for China worldwide for
   * comparable uncontrolled price (CUP) method, bank card, and cross-border transactions.
   */
  countryCode: string;
  /** Customizes the payer experience during the approval process for the payment. */
  experienceContext?: ExperienceContext;
};

export const epsPaymentRequestSchema: Schema<EpsPaymentRequest> = s.object<EpsPaymentRequest>({
  name: s.string(),
  countryCode: s.string(),
  experienceContext: s.optional(s.lazy(() => experienceContextSchema)),
  _keysMap: {
    countryCode: "country_code",
    experienceContext: "experience_context",
  },
});
