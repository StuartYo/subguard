import * as s from "../core/validation/index.js";
import type { Schema } from "../core/validation/schema.js";
import { addressSchema, type Address } from "./address.js";
import { nameSchema, type Name } from "./name.js";
import {
  payPalPaymentTokenCustomerTypeSchema,
  type PayPalPaymentTokenCustomerType,
} from "./pay-pal-payment-token-customer-type.js";
import {
  payPalPaymentTokenUsageTypeSchema,
  type PayPalPaymentTokenUsageType,
} from "./pay-pal-payment-token-usage-type.js";
import { phoneWithTypeSchema, type PhoneWithType } from "./phone-with-type.js";
import { phoneSchema, type Phone } from "./phone.js";
import { usagePatternSchema, type UsagePattern } from "./usage-pattern.js";
import {
  vaultedDigitalWalletShippingDetailsSchema,
  type VaultedDigitalWalletShippingDetails,
} from "./vaulted-digital-wallet-shipping-details.js";

/** Full representation of a PayPal Payment Token. */
export type PayPalPaymentToken = {
  /**
   * The description displayed to the consumer on the approval flow for a digital wallet, as well as
   * on the merchant view of the payment token management experience. exp: PayPal.com.
   */
  description?: string;
  /** Expected business/charge model for the billing agreement. */
  usagePattern?: UsagePattern;
  /** The shipping details. */
  shipping?: VaultedDigitalWalletShippingDetails;
  /**
   * Create multiple payment tokens for the same payer, merchant/platform combination. Use this when
   * the customer has not logged in at merchant/platform. The payment token thus generated, can then
   * also be used to create the customer account at merchant/platform. Use this also when multiple
   * payment tokens are required for the same payer, different customer at merchant/platform. This
   * helps to identify customers distinctly even though they may share the same PayPal account. This
   * only applies to PayPal payment source.
   *
   * @default false
   */
  permitMultiplePaymentTokens?: boolean;
  /** The usage type associated with a digital wallet payment token. */
  usageType?: PayPalPaymentTokenUsageType;
  /**
   * The customer type associated with a digital wallet payment token. This is to indicate whether
   * the customer acting on the merchant / platform is either a business or a consumer.
   */
  customerType?: PayPalPaymentTokenCustomerType;
  /**
   * The internationalized email address.<blockquote><strong>Note:</strong> Up to 64 characters are
   * allowed before and 255 characters are allowed after the <code>@</code> sign. However, the
   * generally accepted maximum length for an email address is 254 characters. The pattern verifies
   * that an unquoted <code>@</code> sign exists.</blockquote>
   */
  emailAddress?: string;
  /** The account identifier for a PayPal account. */
  payerId?: string;
  /** The name of the party. */
  name?: Name;
  /** The phone information. */
  phone?: PhoneWithType;
  /**
   * The portable international postal address. Maps to
   * [AddressValidationMetadata](https://github.com/googlei18n/libaddressinput/wiki/AddressValidationMetadata)
   * and HTML 5.1 [Autofilling form controls: the autocomplete
   * attribute](https://www.w3.org/TR/html51/sec-forms.html#autofilling-form-controls-the-autocomplete-attribute).
   */
  address?: Address;
  /** The account identifier for a PayPal account. */
  accountId?: string;
  /**
   * The phone number, in its canonical international [E.164 numbering plan
   * format](https://www.itu.int/rec/T-REC-E.164/en).
   */
  phoneNumber?: Phone;
};

export const payPalPaymentTokenSchema: Schema<PayPalPaymentToken> = s.object<PayPalPaymentToken>({
  description: s.optional(s.string()),
  usagePattern: s.optional(s.lazy(() => usagePatternSchema)),
  shipping: s.optional(s.lazy(() => vaultedDigitalWalletShippingDetailsSchema)),
  permitMultiplePaymentTokens: s.defaulted(s.boolean(), false),
  usageType: s.optional(s.lazy(() => payPalPaymentTokenUsageTypeSchema)),
  customerType: s.optional(s.lazy(() => payPalPaymentTokenCustomerTypeSchema)),
  emailAddress: s.optional(s.string()),
  payerId: s.optional(s.string()),
  name: s.optional(s.lazy(() => nameSchema)),
  phone: s.optional(s.lazy(() => phoneWithTypeSchema)),
  address: s.optional(s.lazy(() => addressSchema)),
  accountId: s.optional(s.string()),
  phoneNumber: s.optional(s.lazy(() => phoneSchema)),
  _keysMap: {
    usagePattern: "usage_pattern",
    permitMultiplePaymentTokens: "permit_multiple_payment_tokens",
    usageType: "usage_type",
    customerType: "customer_type",
    emailAddress: "email_address",
    payerId: "payer_id",
    accountId: "account_id",
    phoneNumber: "phone_number",
  },
});
