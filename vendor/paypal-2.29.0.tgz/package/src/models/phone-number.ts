import * as s from "../core/validation/index.js";
import type { Schema } from "../core/validation/schema.js";

/**
 * The phone number in its canonical international [E.164 numbering plan
 * format](https://www.itu.int/rec/T-REC-E.164/en)., The phone number, in its canonical
 * international [E.164 numbering plan format](https://www.itu.int/rec/T-REC-E.164/en).
 */
export type PhoneNumber = {
  /**
   * The national number, in its canonical international [E.164 numbering plan
   * format](https://www.itu.int/rec/T-REC-E.164/en). The combined length of the country calling
   * code (CC) and the national number must not be greater than 15 digits. The national number
   * consists of a national destination code (NDC) and subscriber number (SN).
   */
  nationalNumber: string;
};

export const phoneNumberSchema: Schema<PhoneNumber> = s.object<PhoneNumber>({
  nationalNumber: s.string(),
  _keysMap: {
    nationalNumber: "national_number",
  },
});
