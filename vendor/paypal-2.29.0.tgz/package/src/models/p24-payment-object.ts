import * as s from "../core/validation/index.js";
import type { Schema } from "../core/validation/schema.js";

/** Information used to pay using P24(Przelewy24). */
export type P24PaymentObject = {
  /** The full name representation like Mr J Smith. */
  name?: string;
  /**
   * The internationalized email address. Note: Up to 64 characters are allowed before and 255
   * characters are allowed after the \@ sign. However, the generally accepted maximum length for an
   * email address is 254 characters. The pattern verifies that an unquoted \@ sign exists.
   */
  email?: string;
  /**
   * The [two-character ISO 3166-1 code](/api/rest/reference/country-codes/) that identifies the
   * country or region. Note: The country code for Great Britain is GB and not UK as used in the
   * top-level domain names for that country. Use the `C2` country code for China worldwide for
   * comparable uncontrolled price (CUP) method, bank card, and cross-border transactions.
   */
  countryCode?: string;
  /** P24 generated payment description. */
  paymentDescriptor?: string;
  /** Numeric identifier of the payment scheme or bank used for the payment. */
  methodId?: string;
  /** Friendly name of the payment scheme or bank used for the payment. */
  methodDescription?: string;
};

export const p24PaymentObjectSchema: Schema<P24PaymentObject> = s.object<P24PaymentObject>({
  name: s.optional(s.string()),
  email: s.optional(s.string()),
  countryCode: s.optional(s.string()),
  paymentDescriptor: s.optional(s.string()),
  methodId: s.optional(s.string()),
  methodDescription: s.optional(s.string()),
  _keysMap: {
    countryCode: "country_code",
    paymentDescriptor: "payment_descriptor",
    methodId: "method_id",
    methodDescription: "method_description",
  },
});
